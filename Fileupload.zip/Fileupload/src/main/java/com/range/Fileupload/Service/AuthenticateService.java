package com.range.Fileupload.Service;

public interface AuthenticateService {

}
